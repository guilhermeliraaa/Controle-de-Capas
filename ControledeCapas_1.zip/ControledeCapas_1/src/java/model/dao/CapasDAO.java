/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model.dao;

import model.Capas;
import java.sql.*;
import java.util.List;
import java.util.ArrayList;
import util.ConectaDB;
/**
 *
 * @author alunocmc
 */
public class CapasDAO {
   //Atributos
   // Sem atributos
    
    //Métodos
   public boolean insCapas(Capas p_capa) throws ClassNotFoundException {
        //Connectar
        Connection conexao = null;
        try{
            conexao = ConectaDB.conectar(); // Abre a conexão
            Statement stmt = conexao.createStatement();
                        //INSERT INTO capas ( codigo, formato,tamanho ,cor ) VALUES (  555 ,'quadrado', 10 ,'azul');           
                        
            String sql = "INSERT INTO capas ( codigo , formato , tamanho , cor ) VALUES ("
                                                                                     + p_capa.getCodigo()+
                                                                                    ", '" + p_capa.getFormato()+ 
                                                                                    "'," + p_capa.getTamanho()+ 
                                                                                    ",'" + p_capa.getCor()+  "')";
                         
            stmt.executeUpdate(sql); // Executa o SQL: Insert / Delete ou Update
                        
            conexao.close();
            return true;
        }catch(SQLException ex){
            System.out.println(" Exception: " + ex.toString());
            return false;
        }                 
    } 
     
   public Capas consCapaid(Capas capas) throws ClassNotFoundException{
    //Connectar
        Connection conexao = null;
        try{
            conexao = ConectaDB.conectar(); // Abre a conexão
            Statement stmt = conexao.createStatement();                                   
                        
            String sql = "SELECT * from capass where pkid = '" + capas.getId()+ "'";
            ResultSet rs = stmt.executeQuery(sql); //GO - Executar - Select
            
            int n_reg = 0;
            while (rs.next()) {                 
                capas.setId(Integer.parseInt(rs.getString("pkid")));  
                capas.setCodigo( Integer.parseInt(rs.getString("codigo")));  
                capas.setFormato(rs.getString("formato"));                
                capas.setTamanho( Integer.parseInt(rs.getString("tamanho")));                
                capas.setCor(rs.getString("cor"));               
                n_reg++;
            }
            conexao.close();
            
            if (n_reg==0){
                return null;
            }else{
                return capas;
            }
        }catch(SQLException ex){
            System.out.println("Erro:" + ex);
            return null;
        }
    } 
  
   public List consCapaLista() throws ClassNotFoundException{
    //Connectar
        List lista = new ArrayList(); // Minha Lista
        Connection conexao = null;
        try{
            conexao = ConectaDB.conectar(); // Abre a conexão
            Statement stmt = conexao.createStatement();                                   
                        
            String sql = "SELECT * from capass ";
            ResultSet rs = stmt.executeQuery(sql); //GO - Executar - Select
            
            int n_reg = 0;
            while (rs.next()) {                 
                Capas capas = new Capas();
                capas.setId(Integer.parseInt(rs.getString("pkid")));  
                capas.setCodigo( Integer.parseInt(rs.getString("codigo")));  
                capas.setFormato(rs.getString("formato"));                
                capas.setTamanho( Integer.parseInt(rs.getString("tamanho")));                
                capas.setCor(rs.getString("cor"));
                lista.add(capas);
                n_reg++;
            }
            conexao.close();
            
            if (n_reg==0){
                return null;
            }else{
                return lista;
            }
        }catch(SQLException ex){
            System.out.println("Erro:" + ex);
            return null;
        }
    }   
   
   public boolean exCapaId(Capas pesquisa) throws ClassNotFoundException{
    //Connectar
        Connection conexao = null;
        try{
            conexao = ConectaDB.conectar(); // Abre a conexão
            Statement stmt = conexao.createStatement();                                   
                        
            String sql = "DELETE from capass where pkid = " + pesquisa.getId();
            stmt.executeUpdate(sql);            
            conexao.close();            
            return true;
            
        }catch(SQLException ex){
            System.out.println("Erro:" + ex);
            return false;
        }
    } 
   
   public boolean altcapa(Capas p_capa) throws ClassNotFoundException {
        //Connectar
        Connection conexao = null;
        try{
            conexao = ConectaDB.conectar(); // Abre a conexão
            Statement stmt = conexao.createStatement();
                        //UPDATE capas SET id ='5', codigo = 555 , formato ='quadrado', tamanho = 5, cor = 'roxo' WHERE pkid = 5                      
            String sql = "UPDATE capass SET id = " + p_capa.getId()+ " " +
                                       ", codigo = " + p_capa.getCodigo()+ "" +
                                       ", formato ='" + p_capa.getFormato()+ "" +
                                       ", tamanho =" + p_capa.getTamanho()+ 
                                       ", cor     ='" + p_capa.getCor()+ " WHERE pkid = " + p_capa.getId();
                                       
            stmt.executeUpdate(sql); // Executa o SQL: Insert / Delete ou Update
                        
            conexao.close();
            return true;
        }catch(SQLException ex){
            System.out.println(" Exception: " + ex.toString());
            return false;
        }                 
    } 
}
